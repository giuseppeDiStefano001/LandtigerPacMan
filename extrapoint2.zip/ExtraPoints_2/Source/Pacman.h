#ifndef PACMAN_H
#define PACMAN_H

/* Includes ------------------------------------------------------------------*/
#include "LPC17xx.h"
#include "GLCD/GLCD.h" 
#include "TouchPanel/TouchPanel.h"
#include "timer/timer.h"

#define MAP_ROWS 30
#define MAP_COLS 30

#define N 8

#define PIXELS_ROWS 320
#define PIXELS_COLS 240
#define CELL_WIDTH  (PIXELS_ROWS / MAP_ROWS)
#define CELL_HEIGHT (PIXELS_COLS / MAP_COLS)

#define NUM_POWER_PILLS 6

#define DIRECTION_UP 1
#define DIRECTION_RIGHT 2
#define DIRECTION_DOWN 3 
#define DIRECTION_LEFT 4 

#define MODE_CHASE 1
#define MODE_FRIGHTENED 2
#define COLOR_CHASE Red
#define COLOR_FRIGHTENED Cyan

#define MULTIPLY_BASE 14
#define MULTIPLY_MEDIUM 8
#define MULTIPLY_HIGH 4

#define START_PACMAN_X 0x0000000E
#define START_PACMAN_Y 0x00000001

#define START_GHOST_X 0x0000000E
#define START_GHOST_Y 0x0000000E

#define TELETRASPORT_RIGHT_X 0x0000000E
#define TELETRASPORT_RIGHT_Y 0x0000001C

#define TELETRASPORT_LEFT_X 0x0000000E
#define TELETRASPORT_LEFT_Y 0X00000000



extern volatile int map[MAP_ROWS][MAP_COLS];
extern int positionPacManX; 
extern int positionPacManY;
extern int pacManDirection; 
extern int powerPills; 
extern int standardPills; 
extern int points; 
extern int mode; 
extern int powerPillsEaten;
extern volatile int vite;

void turnMapIntoPixels();

void drawBackground(int PIXEL_ROWS, int PIXEL_COLS, uint16_t color);
void drawWalls(int x, int y, uint16_t color);
void drawPowerPill(int x, int y, uint16_t color);
void drawStandardPill(int x, int y, uint16_t color);
void drawPacMan(int x, int y, uint16_t color);
void drawGhost(int x, int y, uint16_t color);
void generatePowerPills(int seed); 

int isValidPosition(int x, int y);
int isValidPositionGhost(int x, int y);
void savePacManPosition(int x, int y);
void saveGhostPosition(int x, int y);
int continueMovement (int direction);
void updatePacmanPosition(int newPacManX, int newPacManY, int prevPacManX, int prevPacManY);
void updateGhostPosition(int mode);
void calculateNewGhostPositionMin(int ghostX, int ghostY, int pacManX, int pacManY, int *newGhostX, int *newGhostY);
void calculateNewGhostPositionMax(int ghostX, int ghostY, int pacManX, int pacManY, int *newGhostX, int *newGhostY);
int manhattan_distance(int x1, int y1, int x2, int y2);
void collisioneGhostPacman(int color);
void checkLifes();
void gameOver();
void victory(); 
#endif 

