/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "LPC17xx.h"
#include "timer.h"
#include "../GLCD/GLCD.h" 
#include "../TouchPanel/TouchPanel.h"
#include <stdio.h> /*for sprintf*/
#include "Pacman.h"
#include "CAN/CAN.h"

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

 
extern int standardPills; 

int generatedPowePills = 0;
static int tempoFrightnedEnd = 0; 

static int countTIM3 = 0; 
static int multiply = MULTIPLY_BASE;

extern int pausa; 
uint8_t tempo = 60; 

extern int points; 

uint16_t SinTable[45] =                                       /* ���ұ�                       */
{
    410, 467, 523, 576, 627, 673, 714, 749, 778,
    799, 813, 819, 817, 807, 789, 764, 732, 694, 
    650, 602, 550, 495, 438, 381, 324, 270, 217,
    169, 125, 87 , 55 , 30 , 12 , 2  , 0  , 6  ,   
    20 , 41 , 70 , 105, 146, 193, 243, 297, 353
};

void TIMER0_IRQHandler (void)
{
	
	if ((standardPills < 240) && (generatedPowePills == 0)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} else if ((standardPills < 160) && (generatedPowePills == 1)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 120) && (generatedPowePills == 2)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 80) && (generatedPowePills == 3)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 40) && (generatedPowePills == 4)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 0) && (generatedPowePills == 5)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	}
	
	tempo--;
	
//	char time[30];
//	sprintf(time, "Tempo: %d ", tempo); 
//	GUI_Text(20,300, (uint8_t *) time, White, Black); 
	
//	char score[30];
//	sprintf(score, "Score: %d ", points); 
//	GUI_Text(20,260, (uint8_t *) score, White, Black); 

	if (tempo == 59){
		pausa = 1; 
		LCD_DrawSolidRectangle(50, 50, 180, 180 , White );
		GUI_Text(92,110, (uint8_t *) " PAUSE", Black, White);
		disable_timer(0);
	}
		
	if(tempo == 0){
		gameOver();
	}
	
	if (standardPills == 0){
		victory();
	}

	LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return; 
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/



void TIMER1_IRQHandler (void)
{	
	static int ticks=0;
	/* DAC management */
	static int currentValue; 
	currentValue = SinTable[ticks];
	currentValue -= 410;
	currentValue /= 1;
	currentValue += 410;
	LPC_DAC->DACR = currentValue <<6;
	ticks++;
	if(ticks==45) ticks=0;	
	
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer2_IRQHandler
**
** Descriptions:		Timer/Counter 2 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/


void TIMER2_IRQHandler (void)
{
	disable_timer(1);
  LPC_TIM2->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer3_IRQHandler
**
** Descriptions:		Timer/Counter 3 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
// beat 1/4 = 1.65/4 seconds
#define RIT_SEMIMINIMA 8
#define RIT_MINIMA 16
#define RIT_INTERA 32

#define UPTICKS 1

NOTE song[] = 
{
	// 1
	{d3, time_semicroma},
	{d3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause1, time_semicroma},
	{a3b, time_semicroma},
	{pause1, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 2
	{c3, time_semicroma},
	{c3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause1, time_semicroma},
	{a3b, time_semicroma},
	{pause1, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 3
	{c3b, time_semicroma},
	{c3b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause1, time_semicroma},
	{a3b, time_semicroma},
	{pause1, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 4
	{a2b, time_semicroma},
	{a2b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause1, time_semicroma},
	{a3b, time_semicroma},
	{pause1, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 5
	
};

 
void TIMER3_IRQHandler (void)
{	
	countTIM3++;
	
	
	if (pausa == 1){
		LPC_TIM3->IR = 1;			/* clear interrupt flag */
		return;
	}
	
	
	if ( powerPillsEaten == 1 ){
		mode = MODE_FRIGHTENED;
		powerPillsEaten = 0; 
		tempoFrightnedEnd = tempo - 10; 
	}
	
	if (tempo == tempoFrightnedEnd){
		mode = MODE_CHASE;
		tempoFrightnedEnd = 0; 
	}
	
	//Gestione velocit� ghost
	if (tempo > 40 && tempo < 60){
		multiply = MULTIPLY_BASE; 
	} else if ( tempo < 40 && tempo > 30){
	  multiply = MULTIPLY_MEDIUM; 
	} else if ( tempo < 30 && tempo > 0){
		multiply =  MULTIPLY_HIGH;
	}
	
	if (countTIM3 >= multiply){
		updateGhostPosition(mode);
		countTIM3 = 0;
	}
	

	

	
	
	
	
	if (pausa == 0){
	static int currentNote = 0;
							static int ticks = 0;
							if(!isNotePlaying())
							{
								++ticks;
							if(ticks == UPTICKS)
							{
							ticks = 0;
							playNote(song[currentNote++]);
								}
							}
	
			if(currentNote == (sizeof(song) / sizeof(song[0])))
		{
			currentNote = 0;
		}
	
	}
	
	
  LPC_TIM3->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
