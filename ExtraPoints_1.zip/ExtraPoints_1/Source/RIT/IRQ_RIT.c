/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "Pacman.h"
#include <stdio.h> /*for sprintf*/

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

volatile int downk0 = 0;
volatile int direction = 0; 

volatile int pause = 0; 

extern int points;

	
void RIT_IRQHandler (void)
{					 
	static int up = 0; 
	static int right=0;
	static int left=0; 
	static int downJ1=0;
  static int select=0;	
  static int newPacManX = 0; 
  static int newPacManY = 0;	
	static int vite = 1; 

	char life[30];
	sprintf(life, "Vite: %d ", vite); 
	GUI_Text(20,280, (uint8_t *) life, White, Black);
	
	char score[30];
	sprintf(score, "Score: %d ", points); 
	GUI_Text(20,260, (uint8_t *) score, White, Black); 
	
	
	if(points == 0x3E8 || points == 0x7D0 && vite < 3){
	 vite++;
	}	
	
	if(( (LPC_GPIO1->FIOPIN & (1<<29) ) == 0 || direction == DIRECTION_UP) && pause == 0){	
		/* Joytick UP pressed */
		up++;
		direction = DIRECTION_UP; 
	  newPacManX = positionPacManX -1; 
		newPacManY = positionPacManY; 
		if (isValidPosition(newPacManX, newPacManY)){
		 updatePacmanPosition(newPacManX, newPacManY, positionPacManX, positionPacManY);
		} else{
		up--; 
		}
		
	}
	else{
			up=0;
	}
	
	if(( (LPC_GPIO1->FIOPIN & (1<<28)) == 0 || direction == DIRECTION_RIGHT) && pause == 0){	
		/* Joytick RIGHT pressed */
		right++;
		direction = DIRECTION_RIGHT; 
	  newPacManX = positionPacManX; 
		newPacManY = positionPacManY + 1; 
		if (isValidPosition(newPacManX, newPacManY)){
		 updatePacmanPosition(newPacManX, newPacManY, positionPacManX, positionPacManY);
		} else{
	  right--; 
		}
  }
	else{
			right=0;
	}
	
	if(( (LPC_GPIO1->FIOPIN & (1<<27)) == 0 || direction == DIRECTION_LEFT) && pause == 0 ){	
		/* Joytick LEFT pressed*/
		left++;
		direction = DIRECTION_LEFT; 
	  newPacManX = positionPacManX; 
		newPacManY = positionPacManY - 1; 
		if (isValidPosition(newPacManX, newPacManY)){
		 updatePacmanPosition(newPacManX, newPacManY, positionPacManX, positionPacManY);
		} else{
	  left--; 
		}
  }
	else{
			left=0;
	}
	
	if(((LPC_GPIO1->FIOPIN & (1<<26)) == 0 || (direction == DIRECTION_DOWN) )&& pause == 0){	
		/* Joytick DOWN pressed*/
		downJ1++;
		direction = DIRECTION_DOWN; 
	  newPacManX = positionPacManX + 1; 
		newPacManY = positionPacManY; 
		if (isValidPosition(newPacManX, newPacManY)){
		 updatePacmanPosition(newPacManX, newPacManY, positionPacManX, positionPacManY);
		} else{
	  downJ1--; 
		}
  }
	else{
			downJ1=0;
	}
	
	
	
	int valoreStandardPills; 
	/////////////////////////////////////////////////////////
	/* button management */
	if(downk0>=1){ 
		if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){	/* INT0 pressed */
			switch(downk0){				
				case 2:
						if (pause == 1){
							pause = 0;
							valoreStandardPills = standardPills; 
							turnMapIntoPixels();
							standardPills = valoreStandardPills;
							enable_timer(0);
						} 
						else if ( pause == 0){
							pause = 1; 
							disable_timer(0);
							LCD_DrawSolidRectangle(50, 50, 180, 180 , White );
							GUI_Text(100,110, (uint8_t *) "PAUSE", Black, White);
						}
						break;
				default:
					break;
			}
			downk0++;
		}
		else {	/* button released */
			downk0=0;			
			NVIC_EnableIRQ(EINT3_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
 
	reset_RIT();
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}



/******************************************************************************
**                            End Of File
******************************************************************************/
