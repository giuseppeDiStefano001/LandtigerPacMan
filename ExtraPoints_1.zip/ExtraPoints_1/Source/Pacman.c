#include <stdio.h>
#include "Pacman.h"
 

uint32_t pixels[PIXELS_ROWS][PIXELS_COLS];
int positionPacManX; 
int positionPacManY;
int standardPills = 0; 
int powerPills = 0; 
int pacManDirection = 0; 

int seed = 0; 
int points = 0; 


volatile int map[MAP_ROWS][MAP_COLS] = {
	  {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1},
    {1, 3, 1, 0, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 1, 0, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 1, 0, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1},
    {1, 3, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 3, 3, 3, 3, 3, 1, 1, 3, 0, 0, 0, 1, 1, 0, 0, 0, 3, 1, 1, 3, 3, 3, 3, 3, 3, 3, 1},
    {1, 3, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 6, 1, 1, 6, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 3, 1},
    {0, 2, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 3, 0},
    {1, 3, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 1, 0, 1, 1, 0, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 6, 1, 1, 0, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 3, 1},
    {1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1},
    {1, 3, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 3, 3, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 1},
    {1, 1, 1, 3, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1},
    {1, 1, 1, 3, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1},
    {1, 3, 3, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 3, 3, 3, 1},
    {1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1},
    {1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
};


void turnMapIntoPixels(){
	 int x,y; 
	 for(x = 0; x < MAP_ROWS; x++){
			for(y = 0; y < MAP_COLS; y++){
				switch (map[x][y]) {
                case 0:
                    drawBackground(x,y, Black);
                    break;
                case 1:
                    drawWalls(x,y,Blue);
                    break;
                case 2:
									   savePacManPosition(x,y);
										 drawPacMan(x,y,Yellow);
                    break;
                case 3:
                     drawStandardPill(x,y,PaleYellow);
										 standardPills++;
                    break;
								case 6: 
										 drawWalls(x,y, Red);
										break;
                default:
									  drawBackground(x,y, Black);
                    break;
				}
	    }
   }
}

	 

void savePacManPosition(int x, int y){
	positionPacManX = x; 
	positionPacManY = y; 
}

int continueMovement (int direction){
  if(direction == DIRECTION_DOWN || direction == DIRECTION_LEFT 
							|| direction == DIRECTION_UP || direction == DIRECTION_RIGHT){
		pacManDirection = direction; 
		return 1;
	  }
	return 0;
}


void drawWalls(int x, int y, uint16_t color){
  int i = x; 
	int j = y;
	
	   for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
             if (i == 0 || i == N - 1 || j == 0 || j == N - 1) {
                LCD_SetPoint(y * N + j, x * N + i, Black);
            } else{
								LCD_SetPoint(y * N + j, x * N + i, color);
						}
        }
	 } 
} 
 

void drawPowerPill(int x, int y, uint16_t color) {
    int r = N / 2;  // Raggio del cerchio (1/4 di N)
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            // Calcolo della distanza al quadrato dal centro della cella
            int dx = i - 4;  // Distanza orizzontale dal centro
            int dy = j - 4;  // Distanza verticale dal centro
            
            // Verifica se il punto (i, j) � dentro il cerchio
            if ((dx * dx + dy * dy) <= (r * r)) {
                // Disegna i punti all'interno o sul bordo del cerchio
                LCD_SetPoint(y * N + j, x * N + i, color);
            } else {
                // Disegna il background
                LCD_SetPoint(y * N + j, x * N + i, Black);
            }
        }
    }
}

 void drawStandardPill(int x, int y, uint16_t color) {
    int r = N / 4;  // Raggio del cerchio (1/4 di N)
    int i, j;


    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            // Calcolo della distanza al quadrato dal centro della cella
            int dx = i - 4;  // Distanza orizzontale dal centro
            int dy = j - 4;  // Distanza verticale dal centro
            
            // Verifica se il punto (i, j) � dentro il cerchio
            if ((dx * dx + dy * dy) <= (r * r)) {
                // Disegna i punti all'interno o sul bordo del cerchio
                LCD_SetPoint(y * N + j, x * N + i, color);
            } else {
                // Disegna il background
                LCD_SetPoint(y * N + j, x * N + i, Black);
            }
        }
    }
}



void drawPacMan(int x, int y, uint16_t color) {
    int r = N / 2;  // Raggio del cerchio (met� della dimensione N)
	  int i,j;
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            // Calcolo della distanza al quadrato dal centro
            int dx = i - r;
            int dy = j - r;

            // Condizione per verificare se il punto � dentro il cerchio
            if ((dx * dx + dy * dy) <= (r * r)) {
                // Escludi l'ottante 8 (destro orizzontale)
                if (dx> 0 && dy >= -dx && dy*dy <= dx) continue;
                // Escludi l'ottante 7 (inferiore destro)
                if (dx > 0 && dy > 0 && dy*dy > dx) continue;
						    LCD_SetPoint(y * N + j, x * N + i, color);
            } else {
                // Disegna lo sfondo
                LCD_SetPoint(y * N + j, x * N + i, Black);
            }
        }
    }
}


void drawBackground(int x, int y, uint16_t color){
	 int i = x; 
	 int j = y; 
   for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
             LCD_SetPoint(y * N + j, x * N + i, color);
        }
	 }
} 



int isValidPosition(int x, int y) {
   // Verifica che la posizone del pacman non sia fuori dalla cella o se vuole entrare nel cancelletto
		if (x < 0 || x > 28 || y < 0 || y > 28){
			return 0; 
		}
		if(map[x][y] == 6){
			 return 0; 
		}
	 // Posizione valida se percorso vuoto(0), se presenta una standard pill(3) o una power pill (4)
	
    if (map[x][y] == 0){
        return 1; 
    }
		
		if (map[x][y] == 2){
        return 1; 
    } 
		
		if (map[x][y] == 3){
				return 1; 
		}
		if (map[x][y] == 4){
				return 1; 
		}
		if(map[x][y] == 7){
			  return 1;
		}
    return 0; // Posizione non valida
}



// Funzione per generare le power pills in modo randomico
void generatePowerPills(int seed) {
   int valoreCella = 0; 
   srand(seed); // Inizializza il generatore di numeri casuali

   int x, y;
   do {
      x = rand() % MAP_ROWS;  // Genera un numero casuale tra 0 e MAP_ROWS-1 per la x
      y = rand() % MAP_COLS;  // Genera un numero casuale tra 0 e MAP_COLS-1 per la y
      valoreCella = map[x][y];
   } while (valoreCella != 3);  // Continua fino a trovare una cella con valore 3
   
   map[x][y] = 4;  // Posiziona la power pill (valore 4) nella mappa
   drawPowerPill(x, y, PaleYellow);  // Disegna la power pill
   powerPills++;   // Incrementa il contatore delle power pills posizionate
   standardPills--;
}

void updatePacmanPosition(int newPacManX, int newPacManY, int prevPacManX, int prevPacManY){

	
	//Disegna la nuova cella in cui si trover� il PacMan
	int valoreNuovaCellaPacMan = map[newPacManX][newPacManY];

	//Trasforma la cella dove si trovava il PacMan inizialmente in una cella vuota
	map[prevPacManX][prevPacManY] = 0; 
	drawBackground(prevPacManX, prevPacManY, Black);
	
	//Se la cella non � occupata da nulla, allora ridisegna semplicemente il pacman
	//Inoltre, presente caso speciale per la gestione del teletrasporto
	if (valoreNuovaCellaPacMan == 0){
		if (newPacManX == 14) {
			if(newPacManY == 0){
				newPacManY = 28; 
			  drawPacMan(newPacManX, newPacManY, Yellow); 
				positionPacManX = newPacManX; 
	      positionPacManY = newPacManY;
				return; 
			}
			if(newPacManY == 28){
				newPacManY = 1; 
			  drawPacMan(newPacManX, newPacManY, Yellow); 
				positionPacManX = newPacManX; 
	      positionPacManY = newPacManY;
				return;
			}
		}
		drawPacMan(newPacManX, newPacManY, Yellow); 
	}
	
	if(valoreNuovaCellaPacMan == 2){
		drawPacMan(newPacManX, newPacManY, Yellow);
	}
	
	//Se la cella � occupata da una powerPill allora decrementa il numero delle power pill e disegna il pacman nella cella
	if (valoreNuovaCellaPacMan == 4){
		powerPills--;
		points = points + 50;
		drawPacMan(newPacManX, newPacManY, Yellow); 
	}
	
	
	//Se la cella � occupata da una standardPill allora decrementa il numero delle standard pill e disegna il pacman nella cella
	if(valoreNuovaCellaPacMan == 3){
		standardPills--; 
		points = points + 10; 
		drawPacMan(newPacManX, newPacManY, Yellow); 
	}
	
	positionPacManX = newPacManX; 
	positionPacManY = newPacManY;
}


