/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "LPC17xx.h"
#include "timer.h"
#include "../GLCD/GLCD.h" 
#include "../TouchPanel/TouchPanel.h"
#include <stdio.h> /*for sprintf*/
#include "Pacman.h"

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

 
extern int standardPills; 
uint8_t tempo = 60; 
int generatedPowePills = 0;
extern int pause; 

void TIMER0_IRQHandler (void)
{
	
	if ((standardPills < 240) && (generatedPowePills == 0)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} else if ((standardPills < 160) && (generatedPowePills == 1)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 120) && (generatedPowePills == 2)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 80) && (generatedPowePills == 3)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 40) && (generatedPowePills == 4)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	} 
	else if ((standardPills > 0) && (generatedPowePills == 5)) {
			generatePowerPills(LPC_TIM0->TC);
			generatedPowePills++;
	}
	
	tempo--;
	
	char time[30];
	sprintf(time, "Tempo: %d ", tempo); 
	GUI_Text(20,300, (uint8_t *) time, White, Black); 

	if (tempo == 59){
		pause = 1; 
		LCD_DrawSolidRectangle(50, 50, 180, 180 , White );
		GUI_Text(95,110, (uint8_t *) "PAUSE", Black, White);
		disable_timer(0);
	}
		
	if(tempo == 0){
		LCD_DrawSolidRectangle(50, 50, 180, 180 , Red );
		GUI_Text(75,110, (uint8_t *) "GAME OVER!", Yellow, Red); 
		disable_timer(0); 
		disable_RIT();
	}
	
	if (standardPills == 0){
		LCD_DrawSolidRectangle(50, 50, 180, 180 , Yellow );
		GUI_Text(80,110, (uint8_t *) " VICTORY! ", Black, Yellow); 
		disable_timer(0);
    disable_RIT(); 		
	}
	
	LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return; 
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{	
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer2_IRQHandler
**
** Descriptions:		Timer/Counter 2 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER2_IRQHandler (void)
{
  LPC_TIM2->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer3_IRQHandler
**
** Descriptions:		Timer/Counter 3 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER3_IRQHandler (void)
{
  LPC_TIM3->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
