#ifndef PACMAN_H
#define PACMAN_H

/* Includes ------------------------------------------------------------------*/
#include "LPC17xx.h"
#include "GLCD/GLCD.h" 
#include "TouchPanel/TouchPanel.h"
#include "timer/timer.h"

#define MAP_ROWS 30
#define MAP_COLS 30

#define N 8

#define PIXELS_ROWS 320
#define PIXELS_COLS 240
#define CELL_WIDTH  (PIXELS_ROWS / MAP_ROWS)
#define CELL_HEIGHT (PIXELS_COLS / MAP_COLS)

#define NUM_POWER_PILLS 6

#define DIRECTION_UP 1
#define DIRECTION_RIGHT 2
#define DIRECTION_DOWN 3 
#define DIRECTION_LEFT 4 

extern volatile int map[MAP_ROWS][MAP_COLS];
extern int positionPacManX; 
extern int positionPacManY;
extern int pacManDirection; 
extern int powerPills; 
extern int standardPills; 
extern int points;  

void turnMapIntoPixels();

void drawBackground(int PIXEL_ROWS, int PIXEL_COLS, uint16_t color);
void drawWalls(int x, int y, uint16_t color);
void drawPowerPill(int x, int y, uint16_t color);
void drawStandardPill(int x, int y, uint16_t color);
void drawPacMan(int x, int y, uint16_t color);
void generatePowerPills(int seed); 

int isValidPosition(int x, int y);
void savePacManPosition(int x, int y);
int continueMovement (int direction);
void updatePacmanPosition(int newPacManX, int newPacManY, int prevPacManX, int prevPacManY);

#endif 

